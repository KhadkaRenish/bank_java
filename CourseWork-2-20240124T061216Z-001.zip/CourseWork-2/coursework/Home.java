package coursework;


/**
 * Write a description of class haha here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import javax.swing.*;
import java.awt.*;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Home 
{
    //Com for main gui
    JPanel panel1,panel2,panel3;
    JFrame frame;
    JButton b1,b2,b3;
    JLabel j1,j2;
 
    //com for debit card
    JFrame frame1;
    JPanel panel4,panel5,panel6;
    JButton b4,b5,b6,b7,b8,b9,b10;
    JLabel j3,j4,j5,j6,j7,j8,j9;
    JTextField t1, t2, t3, t4, t5, t6, t7 ,t8;
    
    //com for credit card
    JFrame frame2;
    JPanel panel7,panel8,panel9;
    JButton b11,b12,b13,b14,b15,b16,b17,b18;
    JLabel j10, j11, j12, j13, j14, j15, j16;
    JTextField t9, t10, t11, t12, t13, t14;
    
    //com for set limit
    JFrame frame3;
    JPanel panel10,panel11,panel12;
    JButton b19,b20,b21,b22,b23,b24;
    JLabel j17,j18,j19,j20,j21,j22,j23;
    JTextField t15,t16,t17,t18;
    JComboBox jcb, jcb1,jcb2;
    
    
    
       public Home () {
    
        frame = new JFrame("My Panels");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(900, 640);
        frame.setLayout(null);
        
        JPanel mainPanel = new JPanel();
        mainPanel.setBounds(0, 0, 900, 600);
        mainPanel.setBackground(Color.black);
        mainPanel.setLayout(null);
  
        panel1 = new JPanel();
        panel1.setBackground(Color.lightGray);
        panel1.setBounds(10, 10, 880, 580);
        panel1.setLayout(null);

        panel2 = new JPanel();
        panel2.setBackground(Color.gray);
        panel2.setBounds(20, 10, 840, 560);
        panel2.setLayout(null);
        
        j1 = new JLabel("Welcome to the future of banking!");
        j1.setBounds(250,0,900,100);
        j1.setFont(new Font("Serif", Font.BOLD, 30));
        
        j2= new JLabel("Our app makes managing your money easier and more securethan ever before.");
        j2.setBounds(154,450,900,100);
        j2.setFont(new Font("Serif", Font.BOLD, 20));
        
        ImageIcon imageIcon = new ImageIcon("/Users/renishkhadka/Documents/Programming/CourseWork-2/coursework/2.png");
        JLabel imageLabel = new JLabel(imageIcon);
        imageLabel.setBounds(50,38, 850, 450);
        
        panel3 = new JPanel();
        panel3.setBackground(Color.black);
        panel3.setBounds(0, 0, 150, 560);
        panel3.setLayout(null);
        
        b1 = new JButton("Home");
        b1.setBounds(0,100,150,65);
        b1.setForeground(Color.black);
        b1.setFont(new Font("Serif", Font.BOLD, 20));
        b1.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                new Home();
                frame.dispose();
            }
            
        });
        
        b2 = new JButton("Debit Card");
        b2.setBounds(0,250,150,65);
        b2.setFont(new Font("Serif", Font.BOLD, 20));
        b2.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                DebitCard();
                
                frame.dispose();
            }
            
        });
        
        b3 = new JButton("Credit Card");
        b3.setBounds(0,400,150,65);
        b3.setFont(new Font("Serif", Font.BOLD, 20));
        
        b3.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                CreditCard();
                frame.dispose();
            }
        });
        

            
        panel1.add(panel2);
        panel2.add(panel3);
        panel2.add(j1);
        panel2.add(j2);
        panel2.add(imageLabel);
        panel3.add(b1);
        panel3.add(b2);
        panel3.add(b3);
        mainPanel.add(panel1);
        frame.add(mainPanel);
        frame.setVisible(true);
        frame.setResizable(false);
        
    }
    public void main(String[] args){
        new Home();
    }
   
    public void DebitCard(){
        frame1 =new JFrame();
        frame1.setSize(900, 640);
        frame1.setLayout(null);
        
        JPanel mainPanel1 = new JPanel();
        mainPanel1.setBounds(0, 0, 900, 600);
        mainPanel1.setBackground(Color.black);
        mainPanel1.setLayout(null);
        
        panel4 = new JPanel();
        panel4.setBackground(Color.lightGray);
        panel4.setBounds(10, 10, 880, 580);
        panel4.setLayout(null);

        panel5 = new JPanel();
        panel5.setBackground(Color.gray);
        panel5.setBounds(20, 10, 840, 560);
        panel5.setLayout(null);
        
        j3 = new JLabel("Debit Card");
        j3.setBounds(425,0,300,100);
        j3.setFont(new Font("Serif", Font.BOLD, 30));
        
        j4=new JLabel("Card_ID:");
        j4.setBounds(160,100,120,20);
        j4.setFont(new Font("Serif", Font.BOLD, 20));
        
        t1=new JTextField();
        t1.setBounds(310,100,140,20);
        
        j5=new JLabel("Issuer Bank:");
        j5.setBounds(160,200,120,20);
        j5.setFont(new Font("Serif", Font.BOLD, 20));
        
        t2=new JTextField();
        t2.setBounds(310,200,140,20);
        
        j6=new JLabel("Balance Amount:");
        j6.setBounds(160,300,170,20);
        j6.setFont(new Font("Serif", Font.BOLD, 20));
        
        t3=new JTextField();
        t3.setBounds(310,300,140,20);
        
        j7=new JLabel("Client Name:");
        j7.setBounds(500,100,170,20);
        j7.setFont(new Font("Serif", Font.BOLD, 20));
        
        t4=new JTextField();
        t4.setBounds(670,100,140,20);
        
        j8=new JLabel("Balance Account:");
        j8.setBounds(500,200,170,20);
        j8.setFont(new Font("Serif", Font.BOLD, 20));
        
        t5=new JTextField();
        t5.setBounds(670,200,140,20);
        
        j9=new JLabel("pin:");
        j9.setBounds(500,300,170,20);
        j9.setFont(new Font("Serif", Font.BOLD, 20));
        
        t6=new JTextField();
        t6.setBounds(670,300,140,20);
        
        b7 = new JButton("Add Debit Card");
        b7.setBounds(160,350,150,55);
        b7.setForeground(Color.black);
        b7.setFont(new Font("Serif", Font.BOLD, 20));
        
        b8 = new JButton("Withdraw from Debit Card");
        b8.setBounds(580,350,250,55);
        b8.setForeground(Color.black);
        b8.setFont(new Font("Serif", Font.BOLD, 20));
        
        b9 = new JButton("Display");
        b9.setBounds(160,420,150,55);
        b9.setForeground(Color.black);
        b9.setFont(new Font("Serif", Font.BOLD, 20));
        
        b10 = new JButton("Clear");
        b10.setBounds(160,490,150,55);
        b10.setForeground(Color.black);
        b10.setFont(new Font("Serif", Font.BOLD, 20));
        
        panel6 = new JPanel();
        panel6.setBackground(Color.black);
        panel6.setBounds(0, 0, 150, 560);
        panel6.setLayout(null);
        
        b4 = new JButton("Home");
        b4.setBounds(0,100,150,65);
        b4.setForeground(Color.black);
        b4.setFont(new Font("Serif", Font.BOLD, 20));
        b4.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                new Home();
                frame1.dispose();
            }
            
        });
        
        b5 = new JButton("Debit Card");
        b5.setBounds(0,250,150,65);
        b5.setFont(new Font("Serif", Font.BOLD, 20));
        
        b6 = new JButton("Credit Card");
        b6.setBounds(0,400,150,65);
        b6.setFont(new Font("Serif", Font.BOLD, 20));
        
        b6.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                CreditCard();
                frame1.dispose();
            }
            
        });
        
        mainPanel1.add(panel4);
        panel4.add(panel5);
        panel5.add(panel6);
        panel6.add(b4);
        panel6.add(b5);
        panel6.add(b6);
        panel5.add(j3);
        panel5.add(j4);
        panel5.add(t1);
        panel5.add(j5);
        panel5.add(t2);
        panel5.add(j6);
        panel5.add(t3);
        panel5.add(j7);
        panel5.add(t4);
        panel5.add(j8);
        panel5.add(t5);
        panel5.add(j9);
        panel5.add(t6);
        panel5.add(b7);
        panel5.add(b8);
        panel5.add(b9);
        panel5.add(b10);
        
        
        frame1.add(mainPanel1);
        frame1.setVisible(true);
        frame1.setResizable(false);
        
        
    }
    public void CreditCard(){
        frame2 =new JFrame();
        frame2.setSize(900, 640);
        frame2.setLayout(null);
        
        JPanel mainPanel2 = new JPanel();
        mainPanel2.setBounds(0, 0, 900, 600);
        mainPanel2.setBackground(Color.black);
        mainPanel2.setLayout(null);
        
        panel7 = new JPanel();
        panel7.setBackground(Color.lightGray);
        panel7.setBounds(10, 10, 880, 580);
        panel7.setLayout(null);

        panel8 = new JPanel();
        panel8.setBackground(Color.gray);
        panel8.setBounds(20, 10, 840, 560);
        panel8.setLayout(null);
        
        j10 = new JLabel("Credit Card");
        j10.setBounds(425,0,300,100);
        j10.setFont(new Font("Serif", Font.BOLD, 30));
        
        j11=new JLabel("Card_ID:");
        j11.setBounds(160,100,120,20);
        j11.setFont(new Font("Serif", Font.BOLD, 20));
        
        t9=new JTextField();
        t9.setBounds(320,100,140,20);
        
        j12=new JLabel("Issuer Bank:");
        j12.setBounds(160,200,120,20);
        j12.setFont(new Font("Serif", Font.BOLD, 20));
        
        t10=new JTextField();
        t10.setBounds(320,200,140,20);
        
        j13=new JLabel("Balance Amount:");
        j13.setBounds(160,300,170,20);
        j13.setFont(new Font("Serif", Font.BOLD, 20));
        
        t11=new JTextField();
        t11.setBounds(320,300,140,20);
        
        j14=new JLabel("Client Name:");
        j14.setBounds(500,100,170,20);
        j14.setFont(new Font("Serif", Font.BOLD, 20));
        
        t12=new JTextField();
        t12.setBounds(670,100,140,20);
        
        j15=new JLabel("Balance Account:");
        j15.setBounds(500,200,170,20);
        j15.setFont(new Font("Serif", Font.BOLD, 20));
        
        t13=new JTextField();
        t13.setBounds(670,200,140,20);
        
        j16=new JLabel("CVC Number:");
        j16.setBounds(500,300,170,20);
        j16.setFont(new Font("Serif", Font.BOLD, 20));
        
        t14=new JTextField();
        t14.setBounds(670,300,140,20);
        
        b14 = new JButton("Add Credit Card");
        b14.setBounds(160,350,180,60);
        b14.setForeground(Color.black);
        b14.setFont(new Font("Serif", Font.BOLD, 20));
        
        b15 = new JButton("Cancel Credit Card");
        b15.setBounds(650,350,180,60);
        b15.setForeground(Color.black);
        b15.setFont(new Font("Serif", Font.BOLD, 20));
        
        b16 = new JButton("Set credit limit");
        b16.setBounds(160,420,180,60);
        b16.setForeground(Color.black);
        b16.setFont(new Font("Serif", Font.BOLD, 20));
        
        b16.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                setlimit();
                frame2.dispose();
            }
            
        });
        
        b17 = new JButton("Display");
        b17.setBounds(650,420,180,60);
        b17.setForeground(Color.black);
        b17.setFont(new Font("Serif", Font.BOLD, 20));
        
        b18 = new JButton("clear");
        b18.setBounds(650,490,180,60);
        b18.setForeground(Color.black);
        b18.setFont(new Font("Serif", Font.BOLD, 20));
        
        panel9 = new JPanel();
        panel9.setBackground(Color.black);
        panel9.setBounds(0, 0, 150, 560);
        panel9.setLayout(null);

        
        b11 = new JButton("Home");
        b11.setBounds(0,100,150,65);
        b11.setForeground(Color.black);
        b11.setFont(new Font("Serif", Font.BOLD, 20));
        
         b11.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                new Home();
                frame2.dispose();
            }
            
        });
        
        b12 = new JButton("Debit Card");
        b12.setBounds(0,250,150,65);
        b12.setFont(new Font("Serif", Font.BOLD, 20));
        
        b12.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                DebitCard();
                frame2.dispose();
            }
            
        });
        
        b13 = new JButton("Credit Card");
        b13.setBounds(0,400,150,65);
        b13.setFont(new Font("Serif", Font.BOLD, 20));
        
        b13.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                CreditCard();
                frame2.dispose();
            }
            
        });
       
         
        
        
        mainPanel2.add(panel7);
        panel7.add(panel8);
        panel8.add(panel9);
        panel9.add(b11);
        panel9.add(b12);
        panel9.add(b13);
        panel8.add(j10);
        panel8.add(j11);
        panel8.add(t9);
        panel8.add(j12);
        panel8.add(t10);
        panel8.add(j13);
        panel8.add(t11);
        panel8.add(j14);
        panel8.add(t12);
        panel8.add(j15);
        panel8.add(t13);
        panel8.add(j16);
        panel8.add(t14);
        panel8.add(b14);
        panel8.add(b15);
        panel8.add(b16);
        panel8.add(b17);
        panel8.add(b18);
        
        frame2.add(mainPanel2);
        frame2.setVisible(true);
        frame2.setResizable(false);
    }
    public void setlimit(){
        frame3 =new JFrame();
        frame3.setSize(900, 640);
        frame3.setLayout(null);
        
        JPanel mainPanel3 = new JPanel();
        mainPanel3.setBounds(0, 0, 900, 600);
        mainPanel3.setBackground(Color.black);
        mainPanel3.setLayout(null);
        
        panel10 = new JPanel();
        panel10.setBackground(Color.lightGray);
        panel10.setBounds(10, 10, 880, 580);
        panel10.setLayout(null);

        panel11 = new JPanel();
        panel11.setBackground(Color.gray);
        panel11.setBounds(20, 10, 840, 560);
        panel11.setLayout(null);
        
        j17 = new JLabel("Set Credit Limit");
        j17.setBounds(425,0,300,100);
        j17.setFont(new Font("Serif", Font.BOLD, 30));
        
        j18=new JLabel("Interest Rate:");
        j18.setBounds(160,100,120,20);
        j18.setFont(new Font("Serif", Font.BOLD, 20));
        
        t15=new JTextField();
        t15.setBounds(320,100,140,20);
        
        j19=new JLabel("Credit Limit:");
        j19.setBounds(500,100,170,20);
        j19.setFont(new Font("Serif", Font.BOLD, 20));
        
        t16=new JTextField();
        t16.setBounds(670,100,140,20);
        
        j20=new JLabel("Grace Period:");
        j20.setBounds(160,200,140,20);
        j20.setFont(new Font("Serif", Font.BOLD, 20));
        
        t17=new JTextField();
        t17.setBounds(320,200,140,20);
        
        j21=new JLabel("Date Of With Draw:");
        j21.setBounds(160,300,190,20);
        j21.setFont(new Font("Serif", Font.BOLD, 20));
        
        String day[]={"1","2","3","4","5","6","7","8","9","10","11","12","13",
            "14","15","16","17","18","19","20","21","22","23","24","25","26",
            "27","28","29","30"};
        jcb= new JComboBox(day);    
        jcb.setBounds(350,295,69,32);
        
        String month[]={"January", "February", "March", "April", "May", 
                       "June", "July" , "August", "September", "October",
                       "November", "December"};
        jcb1= new JComboBox(month);
        jcb1.setBounds(420,295,94,32);
        
        String year[]={"2023","2024","2025","2026","2027","2028"};
        jcb2=new JComboBox(year);
        jcb2.setBounds(520,295,83,32);
        
        b22 = new JButton("Set limit");
        b22.setBounds(160,350,180,60);
        b22.setForeground(Color.black);
        b22.setFont(new Font("Serif", Font.BOLD, 20));
        
        b23 = new JButton("clear");
        b23.setBounds(160,420,180,60);
        b23.setForeground(Color.black);
        b23.setFont(new Font("Serif", Font.BOLD, 20));
        
        b24 = new JButton("Go Back");
        b24.setBounds(650,350,180,60);
        b24.setForeground(Color.black);
        b24.setFont(new Font("Serif", Font.BOLD, 20));
        
        b24.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                CreditCard();
                frame3.dispose();
            }
            
        });
        
        panel12 = new JPanel();
        panel12.setBackground(Color.black);
        panel12.setBounds(0, 0, 150, 560);
        panel12.setLayout(null);
        
        b19 = new JButton("Home");
        b19.setBounds(0,100,150,65);
        b19.setForeground(Color.black);
        b19.setFont(new Font("Serif", Font.BOLD, 20));
        b19.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                new Home();
                frame3.dispose();
            }
            
        });
        
        b20 = new JButton("Debit Card");
        b20.setBounds(0,250,150,65);
        b20.setFont(new Font("Serif", Font.BOLD, 20));
        
        b20.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                DebitCard();
                frame3.dispose();
            }
            
        });
        
        b21 = new JButton("Credit Card");
        b21.setBounds(0,400,150,65);
        b21.setFont(new Font("Serif", Font.BOLD, 20));
        
        b21.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e){
                CreditCard();
                frame3.dispose();
            }
            
        });
        
        
        
        mainPanel3.add(panel10);
        panel10.add(panel11);
        panel11.add(panel12);
        panel12.add(b19);
        panel12.add(b20);
        panel12.add(b21);
        panel11.add(j17);
        panel11.add(j18);
        panel11.add(t15);
        panel11.add(j19);
        panel11.add(t16);
        panel11.add(j20);
        panel11.add(t17);
        panel11.add(j21);
        panel11.add(jcb);
        panel11.add(jcb1);
        panel11.add(jcb2);
        panel11.add(b22);
        panel11.add(b23);
        panel11.add(b24);
        frame3.add(mainPanel3);
        frame3.setVisible(true);
        frame3.setResizable(false);
    }
}

